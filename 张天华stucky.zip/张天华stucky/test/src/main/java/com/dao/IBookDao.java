/**   
 * Copyright © 2018 eSunny Info. Tech Ltd. All rights reserved.
 * 
 * @Package: com.dao 
 * @author: 10424   
 * @date: 2018年9月3日 上午11:19:28 
 */
package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import com.pojo.Book;

/** 
 * @ClassName: BookDao 
 * @Description: 
 * @author: stucky.zhang
 * @date: 2018年9月3日 上午11:19:28  
 */
@Repository 
public interface IBookDao {
	/**
	 * 显示所有书本信息
	 */
	@Select("select * from book")
	List<Book> ShowAll();
	/**
	 * 插入书本数据
	*/
	@Insert("insert into Book(book_id,book_name,book_type,book_price) values (#{book_id},#{book_name},#{book_type},#{book_price})")
    void addBook(Book book); 
   
   /**
    * 书本数据修改
    */
   @Update("update book set book_name=#{book_name},book_age=#{book_age} ,book_price=#{book_price} where book_id=#{book_id}")
    void updateBook(Book book);

   /**
    * 用户数据删除
   */
   @Delete("delete from book where book_id=#{book_id}")
   void deleteBook(int book_id);
  
    /**
   * 根据用户名称查询用户信息
   *
   */
  @Select("SELECT book_id,book_type,book_price FROM book where book_name=#{book_name}")
  List<Book> findByName(@Param("book_name") String book_name);
 
  /**
   * 根据用户ID查询用户信息
   *
   */
  @Select("SELECT book_name,book_price,book_type FROM book where book_id=#{book_id}")     
  List<Book> findById(@Param("book_id") int book_id);
 }

