/**   
 * Copyright © 2018 eSunny Info. Tech Ltd. All rights reserved.
 * 
 * @Package: com.pojo 
 * @author: 10424   
 * @date: 2018年9月3日 上午11:07:46 
 */
package com.pojo;

/** 
 * @ClassName: Book 
 * @Description: TODO
 * @author: stucky.zhang
 * @date: 2018年9月3日 上午11:07:46  
 */
public class Book {
	private int book_id;
	private String book_name;
	private String book_type;
	private int book_price;

	
	
	public Book() {
	}
	

	public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getBook_type() {
		return book_type;
	}
	public void setBook_type(String book_type) {
		this.book_type = book_type;
	}
	public int getBook_price() {
		return book_price;
	}
	public void setBook_price(int book_price) {
		this.book_price = book_price;
	}
	@Override
	public String toString() {
		return "Book [book_id=" + book_id + ", book_name=" + book_name + ", book_type=" + book_type + ", book_price="
				+ book_price + "]";
	}
	

}
