/**   
 * Copyright © 2018 eSunny Info. Tech Ltd. All rights reserved.
 * 
 * @Package: com.service.impl 
 * @author: 10424   
 * @date: 2018年9月3日 下午4:34:31 
 */
package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.IBookDao;
import com.pojo.Book;
import com.service.IBookService;

/** 
 * @ClassName: BookServiceImpl 
 * @Description: TODO
 * @author: stucky.zhang
 * @date: 2018年9月3日 下午4:34:31  
 */
@Service
public class BookServiceImpl implements IBookService {
	@Autowired
    private IBookDao ibookdao;
	public List<Book> ShowAll()
	{
		return ibookdao.ShowAll();
	}

	/* (non Javadoc) 
	 * @Title: addBook
	 * @Description: 添加书本信息
	 * @param book
	 * @return 
	 * @see com.service.IBookService#addBook(com.pojo.Book) 
	 */
	@Override
	public boolean addBook(Book book) {
		 boolean flag=false;
	        try{
	            ibookdao.addBook(book);
	            flag=true;
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	        return flag;
	}

	/* (non Javadoc) 
	 * @Title: upBook
	 * @Description: 更新书本信息
	 * @param book
	 * @return 
	 * @see com.service.IBookService#upBook(com.pojo.Book) 
	 */
	@Override
	public boolean upBook(Book book) {
		boolean flag=false;
        try{
            ibookdao.updateBook(book);
            flag=true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return flag;
    }

	/* (non Javadoc) 
	 * @Title: deleteBook
	 * @Description: 删除书本信息
	 * @param book_id
	 * @return 
	 * @see com.service.IBookService#deleteBook(int) 
	 */
	@Override
	public boolean deleteBook(int book_id) {
		boolean flag=false;
        try{
            ibookdao.deleteBook(book_id);
            flag=true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return flag;
	}

	/* (non Javadoc) 
	 * @Title: findbookByName
	 * @Description: 通过姓名查找书本
	 * @param book_name
	 * @return 
	 * @see com.service.IBookService#findbookByName(java.lang.String) 
	 */
	@Override
	public List<Book> findbookByName(String book_name) {
		List<Book>booklist= ibookdao.findByName(book_name);
		return booklist;
	}

	/* (non Javadoc) 
	 * @Title: findUserById
	 * @Description: 通过书本id查找书本信息
	 * @param book_Id
	 * @return
	 * @see com.service.IBookService#findUserById(int) 
	 */
	@Override
	public List<Book> findBookById(int book_id) {
		List<Book>booklist=ibookdao.findById(book_id);
		return booklist;
	}

}
