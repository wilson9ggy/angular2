/**   
 * Copyright © 2018 eSunny Info. Tech Ltd. All rights reserved.
 * 
 * @Package: com.service 
 * @author: 10424   
 * @date: 2018年9月3日 下午2:44:24 
 */
package com.service;

import java.util.List;

import com.pojo.Book;

/** 
 * @ClassName: IBookService 
 * @Description: TODO
 * @author: stucky.zhang
 * @date: 2018年9月3日 下午2:44:24  
 */
public interface IBookService {
	List<Book> ShowAll();
	/**
     * 新增用户
     * @param user
     * @return
     */
    boolean addBook(Book book);
    
    /**
     * 修改用户
     * @param user
     * @return
     */
    boolean upBook(Book book);
    
    
    /**
     * 删除用户
     * @param id
     * @return
     */
    boolean deleteBook(int book_id);
    
     /**
     * 根据用户名字查询用户信息
     * @param userName
     */
    List<Book>findbookByName(String book_name);
    
    /**
     * 根据用户ID查询用户信息
     * @param userId
     */
    List<Book> findBookById(int book_id);
    
     /**
     * 根据用户ID查询用户信息
     * @param userAge
     */
   
}
