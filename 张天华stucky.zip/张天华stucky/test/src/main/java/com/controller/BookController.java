/**   
 * Copyright © 2018 eSunny Info. Tech Ltd. All rights reserved.
 * 
 * @Package: com.controller 
 * @author: 10424   
 * @date: 2018年9月3日 下午3:03:07 
 */
package com.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.pojo.Book;
import com.service.IBookService;

/** 
 * @ClassName: controller
 * @Description: 
 * @author: stucky.zhang
 * @date: 2018年9月3日 下午3:03:07  
 */
@Controller
public class BookController {
	    @Autowired
	    private IBookService bookservice;
	    
	    /**
	     * 
	    * @Title: ShowAll 
	    * @Description: 显示所有书本信息
	    * @param session
	    * @return String
	    * @author 10424
	    * @date 2018年9月4日下午5:43:05
	     */
	    @RequestMapping("/index")
	    public String ShowAll(HttpSession session) {
	       System.out.println("showAll()");
	       List<Book> books = bookservice.ShowAll();
	       session.setAttribute("booklist1",books);
	       
	        return"index";
	    }
	    /**
	     * 
	    * @Title: toAddBook 
	    * @Description: 跳转到添加页面
	    * @param book
	    * @param session
	    * @return String
	    * @author 10424
	    * @date 2018年9月4日下午5:43:24
	     */
	  
	    @RequestMapping(value = "/addBook", method = RequestMethod.GET)
	    public String toAddBook(Book book,HttpSession session) {
	        return"add";
	    }
	    /**
	     * 
	    * @Title: addBook 
	    * @Description: 新增书本信息
	    * @param book
	    * @param session
	    * @return String
	    * @author 10424
	    * @date 2018年9月4日下午5:43:38
	     */
	    @RequestMapping(value = "/addBook", method = RequestMethod.POST)
	    public String addBook(Book book,HttpSession session) {
	    	System.out.println("开始新增...");
	    	System.out.println(book);
	    	boolean addBook1 = bookservice.addBook(book);
	    	session.setAttribute("booklist1",book);
	    	return"redirect:index";
	    }
	    /**
	     * 
	    * @Title: toUpdateBook 
	    * @Description: 跳转到update页面
	    * @param book_id
	    * @param session
	    * @return String
	    * @author 10424
	    * @date 2018年9月4日下午5:43:54
	     */
	    @RequestMapping(value = "/updateBook", method = RequestMethod.GET)
	    public String toUpdateBook( Integer book_id,HttpSession session) {
	    	session.setAttribute("booklist5",bookservice.findBookById(book_id));
	    	return "update";
	        
	    }
	    /**
	     * 
	    * @Title: updateBook 
	    * @Description: 更新书本信息
	    * @param book
	    * @param session
	    * @return String
	    * @author 10424
	    * @date 2018年9月4日下午5:44:16
	     */
	    @RequestMapping(value = "/updateBook", method = RequestMethod.PUT)
	    public String updateBook( Book book,HttpSession session) {
	        System.out.println("开始更新...");
	        session.setAttribute("booklist2",bookservice.upBook(book));
	        return"redirect:index";
	        
	    }
	    /**
	     * 
	    * @Title: delete 
	    * @Description: 删除书本信息 删除成功之后跳转到index页面
	    * @param book_id
	    * @param session
	    * @return String
	    * @author 10424
	    * @date 2018年9月4日下午5:44:32
	     */
	    
	    @RequestMapping(value = "/deleteBook", method = RequestMethod.DELETE)
	    public String delete(@RequestParam(value = "book_name", required = true) int book_id,HttpSession session) {
	        System.out.println("开始删除...");
	       
	        session.setAttribute("booklist3",bookservice.deleteBook(book_id));
	        return "index";
	  
	    }
}
	    
	
	    
	    

