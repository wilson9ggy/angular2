/**
 * Project Name:springbootTest
 * File Name:AccountServiceImpl.java
 * Package Name:com.springboottest.service.impl
 * Date:2018年9月3日下午9:26:58
 * Copyright (c) 2018, 821802688@qq.com All Rights Reserved.
 *
 */
package com.springboottest.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboottest.dao.AccountDao;

import com.springboottest.pojo.Account;
import com.springboottest.service.AccountService;

/**
 * ClassName: AccountServiceImpl <br/>
 * Description: AccountServiceImpl. <br/><br/>
 * date: 2018年9月3日 下午9:26:58 <br/>
 *
 * @author Jeremy.zhou
 * @version V1.0
 * @since JDK 1.8
 */
@Service
public class AccountServiceImpl implements AccountService {
	
//	@Autowired
//    private AccountRepository accountRepository;
	@Autowired
	private AccountDao accountdao;
	

    @Override
    public List<Account> getAccountList() {
        return accountdao.queryAllAccount();
    }

    @Override
    public Account findAccountById(int account_id) {
        return accountdao.queryAccountById(account_id);
    }

    @Override
    public void save(Account account) {
    	accountdao.addAccount(account);
    }

    @Override
    public void edit(Account account) {
    	accountdao.updateAccount(account);
    }

    @Override
    public void delete(int account_id) {
    	accountdao.deleteAccountById((int) account_id);
    }

}
