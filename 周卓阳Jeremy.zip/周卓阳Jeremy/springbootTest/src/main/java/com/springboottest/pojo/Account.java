/**
 * Project Name:springbootTest
 * File Name:Account.java
 * Package Name:com.springboottest.pojo
 * Date:2018年9月3日下午4:54:58
 * Copyright (c) 2018, 821802688@qq.com All Rights Reserved.
 *
 */
package com.springboottest.pojo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * ClassName: Account <br/>
 * Description: Account. <br/><br/>
 * date: 2018年9月3日 下午4:54:58 <br/>
 *
 * @author Jeremy.zhou
 * @version V1.0
 * @since JDK 1.8
 */
@Entity
public class Account implements Serializable {
	
	/**
	 * serialVersionUID
	 * @since JDK 1.8
	 */
	private static final long serialVersionUID = -7707736352840608864L;
	@Id
	private	Integer	account_id;			//账户编号
	@Column
	private	String	account_name;		//账户名称
	@Column
	private	String	account_pwd;		//账户密码
	@Column
	private	Integer	account_status;		//账户状态
	@Column
	private	Integer	account_type;		//账户类型
	@Column
	private	String	account_comment;	//账户备注
	
	
	public Account() {
		
	}
	
	public Integer getAccount_id() {
		return account_id;
	}
	public void setAccount_id(Integer account_id) {
		this.account_id = account_id;
	}
	public String getAccount_name() {
		return account_name;
	}
	public void setAccount_name(String account_name) {
		this.account_name = account_name;
	}
	public String getAccount_pwd() {
		return account_pwd;
	}
	public void setAccount_pwd(String account_pwd) {
		this.account_pwd = account_pwd;
	}
	public Integer getAccount_status() {
		return account_status;
	}
	public void setAccount_status(Integer account_status) {
		this.account_status = account_status;
	}
	public Integer getAccount_type() {
		return account_type;
	}
	public void setAccount_type(Integer account_type) {
		this.account_type = account_type;
	}
	public String getAccount_comment() {
		return account_comment;
	}
	public void setAccount_comment(String account_comment) {
		this.account_comment = account_comment;
	}
	
	

}
