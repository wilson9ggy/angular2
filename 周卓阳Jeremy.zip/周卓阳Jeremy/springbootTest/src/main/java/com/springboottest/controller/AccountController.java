/**
 * Project Name:springbootTest
 * File Name:AccountController.java
 * Package Name:com.springboottest.controller
 * Date:2018年9月3日下午4:55:46
 * Copyright (c) 2018, 821802688@qq.com All Rights Reserved.
 *
 */
package com.springboottest.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springboottest.pojo.Account;
import com.springboottest.service.AccountService;

/**
 * ClassName: AccountController <br/>
 * Description: AccountController. <br/><br/>
 * date: 2018年9月3日 下午4:55:46 <br/>
 *
 * @author Jeremy.zhou
 * @version V1.0
 * @since JDK 1.8
 */
@Controller
public class AccountController {

   
    
//	@Resource(name="accountRepository")
//    AccountRepository accountRepository;
    @Resource
    AccountService accountService;
	
    @GetMapping(value = "/account")
	public String listAccount(HttpServletRequest request,HttpServletResponse reponse,Model model) {
		List<Account> accounts = accountService.getAccountList();
		model.addAttribute("accounts", accounts);
		return "listAccount";
	}
    
    
    @RequestMapping("/toSave")
    public String toSave() {
        return "addAccount";
    }
    @RequestMapping("/toEdit")
    public String toEdit(Model model, @RequestParam("account_id") String id ) {
    	int id1 = Integer.parseInt(id);
    	 Account account=accountService.findAccountById(id1);
         model.addAttribute("cus", account);
    	return "edit";
    }
    

    @PutMapping("/edit")
    public String edit (Account account) {
    	accountService.edit(account);
        return "redirect:account";
    }
    
    @GetMapping(value = "/saveaccount")
    public String saveAccount(Account account) {
    	accountService.save(account);	
    	return "redirect:account";
    }
    
    @GetMapping(value = "/delete")
    public String delete(@RequestParam("account_id") String id){
    	int id1 = Integer.parseInt(id);
    	accountService.delete(id1);
        return "redirect:account";
    }

}
