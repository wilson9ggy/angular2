///**
// * Project Name:springboottest
// * File Name:AccountRepository.java
// * Package Name:com.springboottest.dao
// * Date:2018年9月3日下午4:55:21
// * Copyright (c) 2018, 821802688@qq.com All Rights Reserved.
// *
// */
//package com.springboottest.dao;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import com.springboottest.pojo.Account;
//
///**
// * ClassName: AccountRepository <br/>
// * Description: TODO ADD REASON(可选). <br/><br/>
// * date: 2018年9月3日 下午4:55:21 <br/>
// *
// * @author Jeremy.zhou
// * @version V1.0
// * @since JDK 1.8
// */
//@Repository(value="accountRepository")
//public interface AccountRepository extends JpaRepository<Account,Integer> {
//	
//	Account findAccountById(int account_id);
//}
