/**
 * Project Name:springbootTest
 * File Name:AccountDao.java
 * Package Name:com.springboottest.dao
 * Date:2018年9月3日下午9:57:42
 * Copyright (c) 2018, 821802688@qq.com All Rights Reserved.
 *
 */
package com.springboottest.dao;

import java.util.List;

import com.springboottest.pojo.Account;

/**
 * ClassName: AccountDao <br/>
 * Description: AccountDao. <br/><br/>
 * date: 2018年9月3日 下午9:57:42 <br/>
 *
 * @author Jeremy.zhou
 * @version V1.0
 * @since JDK 1.8
 */
public interface AccountDao {
	/**
	 * 
	 * queryAllAccount:查询所有的账户信息. <br/>
	 * @author david.dou
	 * @return
	 */
	public List<Account> queryAllAccount();

	/**
	 * 
	 * queryAccountById:根据账户ID查询账户信息 <br/>
	 * @author david.dou
	 * @param account_id
	 * @return
	 */
	public Account queryAccountById(int account_id);
	

	
	/**
	 * 
	 * addAccount:添加新账户. <br/>
	 * @author david.dou
	 * @param account
	 * @return
	 */
	
	public int addAccount(Account account);
	/** 
	 * updateAccount:修改账户信息. <br/>
	 * @author david.dou
	 * @param account
	 * @return
	 */
	public int updateAccount(Account account);
	
	/**
	 * deleteAccountById:(). <br/>
	
	 * @author Jeremy.zhou
		 * @param n1
		 * @param n2
		 * @return
		 * @since JDK 1.8
	 */
	public int deleteAccountById(int accountId);

}
