/**
 * Project Name:springbootTest
 * File Name:AccountService.java
 * Package Name:com.springboottest.service
 * Date:2018年9月3日下午9:26:42
 * Copyright (c) 2018, 821802688@qq.com All Rights Reserved.
 *
 */
package com.springboottest.service;

import java.util.List;

import com.springboottest.pojo.Account;

/**
 * ClassName: AccountService <br/>
 * Description: AccountService. <br/><br/>
 * date: 2018年9月3日 下午9:26:42 <br/>
 *
 * @author Jeremy.zhou
 * @version V1.0
 * @since JDK 1.8
 */
public interface AccountService {
	List<Account> getAccountList();

	Account findAccountById(int id);

	void save(Account account);

	void edit(Account account);

	void delete(int id);


}
