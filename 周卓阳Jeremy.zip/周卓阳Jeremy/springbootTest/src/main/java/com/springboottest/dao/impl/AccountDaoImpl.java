/**
 * Project Name:springbootTest
 * File Name:AccountDaoImpl.java
 * Package Name:com.springboottest.dao.impl
 * Date:2018年9月3日下午9:57:55
 * Copyright (c) 2018, 821802688@qq.com All Rights Reserved.
 *
 */
package com.springboottest.dao.impl;

import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.springboottest.dao.AccountDao;
import com.springboottest.pojo.Account;



/**
 * ClassName: AccountDaoImpl <br/>
 * Description: AccountDaoImpl. <br/><br/>
 * date: 2018年9月3日 下午9:57:55 <br/>
 *
 * @author Jeremy.zhou
 * @version V1.0
 * @since JDK 1.8
 */
@Repository
public class AccountDaoImpl extends JdbcDaoSupport implements AccountDao{
	List<Account> accounts;
	Object params[];
	@Autowired
	AccountDaoImpl(DataSource dataSource) {
        setDataSource(dataSource);
    }
	private static final String SQL_DELETE_ACCOUNTBYID = "DELETE FROM ACCOUNT WHERE ACCOUNT_ID = ?";
	private static final String QUERY_ALL_ACCOUNT = "SELECT * FROM ACCOUNT";
	private static final String QUERY_ACCOUNT_BY_ID = "SELECT ACCOUNT_ID,ACCOUNT_NAME,ACCOUNT_PWD,ACCOUNT_STATUS,ACCOUNT_TYPE,ACCOUNT_COMMENT FROM ACCOUNT WHERE ACCOUNT_ID = ?";
	private static final String INSERT_ACCOUNT = "INSERT INTO ACCOUNT(ACCOUNT_NAME,ACCOUNT_PWD,ACCOUNT_STATUS,ACCOUNT_TYPE,ACCOUNT_COMMENT) VALUES(?,?,?,?,?)";
	private static final String UPDATE_ACCOUNT = "UPDATE ACCOUNT SET " + "ACCOUNT_NAME=?, " + "ACCOUNT_PWD=?,"
			+ " ACCOUNT_STATUS=?," + "ACCOUNT_TYPE=? ," + "ACCOUNT_COMMENT=? " + "WHERE " + "ACCOUNT_ID= ? ";
	/**
	 * @see com.springboottest.dao.AccountDao#queryAllAccount()
	 */
	@Override
	public List<Account> queryAllAccount() {
		accounts =this.getJdbcTemplate().query(QUERY_ALL_ACCOUNT, new BeanPropertyRowMapper<Account>(Account.class));
		return accounts;
	}

	/**
	 * @see com.springboottest.dao.AccountDao#queryAccountById(int)
	 */
	@Override
	public Account queryAccountById(int account_id) {
		Account p=null;
		params = new Object[]{account_id};
		accounts =this.getJdbcTemplate().query( QUERY_ACCOUNT_BY_ID, params,new BeanPropertyRowMapper<Account>(Account.class));
		Iterator<Account> it = accounts.iterator();
		while(it.hasNext()) {
			p = it.next();
		}
		return p;
	}



	/**
	 * @see com.springboottest.dao.AccountDao#addAccount(com.springboottest.model.Account)
	 */
	@Override
	public int addAccount(Account account) {
		int n=0;
		params=new Object[]{account.getAccount_name(),
				account.getAccount_pwd(),
				account.getAccount_status(),
				account.getAccount_type(),account.getAccount_comment()
			};	         
		n = this.getJdbcTemplate().update(INSERT_ACCOUNT,params);          
		return n;
	}

	/**
	 * @see com.springboottest.dao.AccountDao#updateAccount(com.springboottest.model.Account)
	 */
	@Override
	public int updateAccount(Account account) {
		int n=0;
		params=new Object[]{account.getAccount_name(),account.getAccount_pwd(),
				account.getAccount_status(),
				account.getAccount_type(),account.getAccount_comment(),account.getAccount_id()};	         
		n = this.getJdbcTemplate().update(UPDATE_ACCOUNT,params);          
		return n;
	}
	
	/**
	 * 
	 * TODO 简单描述该方法的实现功能（可选）.
	 * 
	 * @see main.java.com.clps.dev.sms.sm.dao.AccountDao#deleteAccountById(java.lang.Integer)
	 */
	@Override
	public int deleteAccountById(int accountId) {
		Object params[] = { accountId };
		int n = 0;

			n = this.getJdbcTemplate().update(SQL_DELETE_ACCOUNTBYID, params);
		logger.info("成功删除" + n + "条数据！");
	
		return n;
	}

}
