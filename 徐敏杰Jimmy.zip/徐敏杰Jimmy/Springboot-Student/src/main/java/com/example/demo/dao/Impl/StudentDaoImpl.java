/**
 * Project Name:Springboot-Student
 * File Name:StudentDaoImpl.java
 * Package Name:com.example.demo.dao.Impl
 * Date:2018年9月3日下午4:40:58
 * Copyright (c) 2018, 15021734680@163.com All Rights Reserved.
 *
 */
package com.example.demo.dao.Impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.print.attribute.standard.RequestingUserName;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.integration.IntegrationProperties.Jdbc;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor;

import com.example.demo.dao.IStudentDao;
import com.example.demo.model.Student;
import com.example.demo.student_controller.studentcontroller;


/**
 * ClassName: StudentDaoImpl <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月3日 下午4:40:58 <br/>
 *
 * @author Jimmy.Xu
 * @version V1.0
 * @since Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
 */
@Repository

public class StudentDaoImpl implements IStudentDao{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	int n=0;
	public final String SQL_INSERT = "INSERT INTO STUDENT (SNAME,GENDER,MOBILE) VALUES (?,?,?)";
	public final String SQL_DELETE ="DELETE FROM STUDENT WHERE SNO=?";
	public final String SQL_MODIFY = "UPDATE STUDENT SET SNAME=?,GENDER=?,MOBILE=? WHERE SNO=?";
	public final String SQL_QUERY = "SELECT SNO,SNAME,GENDER,MOBILE FROM STUDENT";
	public final String SQL_QUERY_BYID="SELECT SNAME,GENDER,MOBILE FROM STUDENT WHERE SNO=?";
	
	
	/**
	 * @see com.example.demo.dao.IStudentDao#insert_Student()
	 */
	@Override
	public int insert_Student(Student student) {
		Object params[]= {student.getSname(),student.getGender(),student.getMobile()};
		n=jdbcTemplate.update(SQL_INSERT,params);
		return n;
	}

	/**
	 * @see com.example.demo.dao.IStudentDao#delete_Student()
	 */
	@Override
	public int delete_Student(int sno) {
		n=jdbcTemplate.update(SQL_DELETE,sno);
		return n;
	}

	/**
	 * @see com.example.demo.dao.IStudentDao#modify_Student()
	 */
	@Override
	public int modify_Student(Student student) {
		Object params[]= {student.getSname(),student.getGender(),student.getMobile(),student.getSno()};
		n=jdbcTemplate.update(SQL_MODIFY,params);
			return n;
	}

	/**
	 * @see com.example.demo.dao.IStudentDao#query_Student()
	 */
	@Override
	public List<Student> query_Student() {
		List<Student> aList=jdbcTemplate.query(SQL_QUERY, new BeanPropertyRowMapper<Student>(Student.class));
		return aList;
	}

	/**
	 * TODO 简单描述该方法的实现功能（可选）.
	 * @see com.example.demo.dao.IStudentDao#query_StudentById(int)
	 */
	@Override
	public Student query_StudentById(int sno) {
		Student student=jdbcTemplate.queryForObject(SQL_QUERY_BYID, new BeanPropertyRowMapper<Student>(Student.class), sno);
		return student;
	}
	
}
