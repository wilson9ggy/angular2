/**
 * Project Name:Springboot-Student
 * File Name:studentcontroller.java
 * Package Name:com.example.demo.student_controller
 * Date:2018年9月3日下午4:39:19
 * Copyright (c) 2018, 15021734680@163.com All Rights Reserved.
 *
 */
package com.example.demo.student_controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.apache.jasper.tagplugins.jstl.core.Out;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.dao.IStudentDao;
import com.example.demo.dao.Impl.StudentDaoImpl;
import com.example.demo.model.Student;


/**
 * ClassName: studentcontroller <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月3日 下午4:39:19 <br/>
 *
 * @author Jimmy.Xu
 * @version V1.0
 * @since Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
 */
@Controller
public class studentcontroller {
	@Autowired
	private IStudentDao studentdao;
	   @RequestMapping("/")
	    public String index() {
	        return "redirect:/index";
	    }

	  @RequestMapping("/index")
	  public String hello(HttpSession session){
		  List<Student> aList=studentdao.query_Student();
		  session.setAttribute("student", aList);
		  return "/index";
	  }
	  @RequestMapping("/toEdit")
	    public String toEdit(Model model,int sno) {
	        Student student=studentdao.query_StudentById(sno);
	        student.setSno(sno);
	        model.addAttribute("student", student);
	        return "edit";
	    }
	  @RequestMapping("/edit")
	    public String edit(Student student) {
	        studentdao.modify_Student(student);
	        return "redirect:/index";
	    }
	  
	  @RequestMapping("/delete")
	    public String delete(int sno) {
	        studentdao.delete_Student(sno);
	        return "redirect:/index";
	    }
	  @RequestMapping("/toAdd")
	    public String toAdd() {
	        return "add";
	    }
	  
	  @RequestMapping("/add")
	    public String add(Student student) {
	        studentdao.insert_Student(student);
	        return "redirect:/index";
	    }

}