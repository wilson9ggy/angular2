/**
 * Project Name:Springboot-Student
 * File Name:IStudentDao.java
 * Package Name:com.example.demo.dao
 * Date:2018年9月3日下午4:40:38
 * Copyright (c) 2018, 15021734680@163.com All Rights Reserved.
 *
 */
package com.example.demo.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.model.Student;
import com.example.demo.student_controller.studentcontroller;

/**
 * ClassName: IStudentDao <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月3日 下午4:40:38 <br/>
 *
 * @author Jimmy.Xu
 * @version V1.0
 * @since Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
 */
@Repository
public interface IStudentDao {
	/**
	 * 
	 * insert_Student:(增加学信息). <br/>
	 * 0为失败，1为成功
	 *
	 * @author Jimmy.Xu
	 * @return
	 * @since Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public int insert_Student(Student student);
	/**
	 * 
	 * delete_Student:(删除学生信息). <br/>
	 * 0为失败，1为成功
	 *
	 * @author Jimmy.Xu
	 * @return
	 * @since Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public int delete_Student(int sno);
	/**
	 * 
	 * modify_Student:(修改学生信息). <br/>
	 *  0为失败，1为成功
	 *
	 * @author Jimmy.Xu
	 * @return
	 * @since Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public int modify_Student(Student student);
	/**
	 * 
	 * query_Student:(查询学生信息). <br/>
	 *  0为失败，1为成功
	 *
	 * @author Jimmy.Xu
	 * @return
	 * @since Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public List<Student> query_Student();
	/**
	 * 
	 * query_StudentById:根据学号查询学生信息. <br/>
	 *
	 * @author Jimmy.Xu
	 * @param sno
	 * @return
	 * @since Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public Student query_StudentById(int sno);
}
