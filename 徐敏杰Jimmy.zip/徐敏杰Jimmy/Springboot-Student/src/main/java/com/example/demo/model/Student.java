/**
 * Project Name:Springboot-Student
 * File Name:Student.java
 * Package Name:com.example.demo.model
 * Date:2018年9月3日下午4:40:20
 * Copyright (c) 2018, 15021734680@163.com All Rights Reserved.
 *
 */
package com.example.demo.model;

import java.io.Serializable;


import org.springframework.beans.factory.annotation.Autowired;

/**
 * ClassName: Student <br/>
 * Description: TODO ADD REASON(可选). <br/>
 * <br/>
 * date: 2018年9月3日 下午4:40:20 <br/>
 *
 * @author Jimmy.Xu
 * @version V1.0
 * @since Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
 */
public class Student{
	private int sno;
	private String sname;
	private int gender;
	private String mobile;
	/**
	 * sno.
	 *
	 * @return  the sno
	 * @since   Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public int getSno() {
		return sno;
	}
	/**
	 * sno.
	 *
	 * @param   sno    the sno to set
	 * @since   Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public void setSno(int sno) {
		this.sno = sno;
	}
	/**
	 * sname.
	 *
	 * @return  the sname
	 * @since   Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public String getSname() {
		return sname;
	}
	/**
	 * sname.
	 *
	 * @param   sname    the sname to set
	 * @since   Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public void setSname(String sname) {
		this.sname = sname;
	}
	/**
	 * gender.
	 *
	 * @return  the gender
	 * @since   Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public int getGender() {
		return gender;
	}
	/**
	 * gender.
	 *
	 * @param   gender    the gender to set
	 * @since   Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public void setGender(int gender) {
		this.gender = gender;
	}
	/**
	 * mobile.
	 *
	 * @return  the mobile
	 * @since   Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public String getMobile() {
		return mobile;
	}
	/**
	 * mobile.
	 *
	 * @param   mobile    the mobile to set
	 * @since   Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	/**
	 * Creates a new instance of Student.
	 *
	 * @param sno
	 * @param sname
	 * @param gender
	 * @param mobile
	 */
	
	public Student(int sno, String sname, int gender, String mobile) {
		super();
		this.sno = sno;
		this.sname = sname;
		this.gender = gender;
		this.mobile = mobile;
	}
	/**
	 * Creates a new instance of Student.
	 *
	 */
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * TODO 简单描述该方法的实现功能（可选）.
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Student [sno=" + sno + ", sname=" + sname + ", gender=" + gender + ", mobile=" + mobile + "]";
	}

}
