/**
 * Project Name:Springboot-Student
 * File Name:StudentDaoImplTest.java
 * Package Name:com.example.demo.dao.Impl
 * Date:2018年9月4日下午1:47:37
 * Copyright (c) 2018, 15021734680@163.com All Rights Reserved.
 *
 */
package com.example.demo.dao.Impl;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.example.demo.dao.IStudentDao;

/**
 * ClassName: StudentDaoImplTest <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月4日 下午1:47:37 <br/>
 *
 * @author Jimmy.Xu
 * @version V1.0
 * @since Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
 */
public class StudentDaoImplTest {

	/**
	 * setUp:(这里用一句话描述这个方法的作用). <br/>
	 * TODO(这里描述这个方法适用条件 – 可选).<br/>
	 * TODO(这里描述这个方法的执行流程 – 可选).<br/>
	 * TODO(这里描述这个方法的使用方法 – 可选).<br/>
	 * TODO(这里描述这个方法的注意事项 – 可选).<br/>
	 *
	 * @author Jimmy.Xu
	 * @throws java.lang.Exception
	 * @since Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * tearDown:(这里用一句话描述这个方法的作用). <br/>
	 * TODO(这里描述这个方法适用条件 – 可选).<br/>
	 * TODO(这里描述这个方法的执行流程 – 可选).<br/>
	 * TODO(这里描述这个方法的使用方法 – 可选).<br/>
	 * TODO(这里描述这个方法的注意事项 – 可选).<br/>
	 *
	 * @author Jimmy.Xu
	 * @throws java.lang.Exception
	 * @since Java(TM) SE Runtime Environment (build 1.8.0_91-b14)
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link com.example.demo.dao.Impl.StudentDaoImpl#insert_Student(java.lang.String, int, java.lang.String)}.
	 */
	@Test
	public void testInsert_Student() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.example.demo.dao.Impl.StudentDaoImpl#delete_Student(int)}.
	 */
	@Test
	public void testDelete_Student() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.example.demo.dao.Impl.StudentDaoImpl#modify_Student(java.lang.String, int, java.lang.String)}.
	 */
	@Test
	public void testModify_Student() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.example.demo.dao.Impl.StudentDaoImpl#query_Student()}.
	 */
	@Test
	public void testQuery_Student() {
		IStudentDao a=new StudentDaoImpl();
		a.query_Student();
	}

}
