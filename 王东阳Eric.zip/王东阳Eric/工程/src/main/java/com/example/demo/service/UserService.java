package com.example.demo.service;

import java.util.List;

import com.example.demo.model.User;

/**
 * ClassName: UserService <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月1日 下午3:45:23 <br/>
 *
 * @author Eric.wang
 * @version V1.0
 * @since JDK 1.8
 */
public interface UserService {

	List<User> getUserList();

	User findUserById(long id);

	void save(User user);

	void edit(User user);

	void delete(long id);

}
