/**
 * Project Name:Userdemo
 * File Name:das.java
 * Package Name:com.example.Userdemo.Repository
 * Date:2018年9月1日下午3:41:13
 * Copyright (c) 2018, erwin.wang@clpsglobal.com All Rights Reserved.
 *
 */
package com.example.demo.Repository;

import com.example.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.
        demo.model.User;

/**
 * ClassName: UserRepository <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月1日 下午3:41:13 <br/>
 *
 * @author Eric.wang
 * @version V1.0
 * @since JDK 1.8
 */
public interface UserRepository extends JpaRepository<User, Long> {
    User findById(long id);
    Long deleteById(long id);
}
