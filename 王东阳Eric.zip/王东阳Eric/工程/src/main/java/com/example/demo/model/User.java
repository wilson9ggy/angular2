/**
 * Project Name:Userdemo
 * File Name:User.java
 * Package Name:com.example.Userdemo.model
 * Date:2018年9月1日下午3:37:51
 * Copyright (c) 2018, erwin.wang@clpsglobal.com All Rights Reserved.
 *
 */
package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


/**
 * ClassName: User <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月1日 下午3:37:51 <br/>
 *
 * @author Eric.wang
 * @version V1.0
 * @since JDK 1.8
 */
@Entity
public class User {
    public User() {
		super();
		
	}
	@Id
    @GeneratedValue
    private long id;
    @Column(nullable = false, unique = true)
    private String userName;
    @Column(nullable = false)
    private String password;
    @Column(nullable = false)
    private int age;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}



