package servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Tqingjia;
import model.Txuesheng;

import service.utilService;
import util.DB;


public class qingjia_servlet extends HttpServlet {
    public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String type = req.getParameter("type");

        if (type.endsWith("qingjiaAdd")) {
            qingjiaAdd(req, res);
        }
        if (type.endsWith("qingjiaMine")) {
            qingjiaMine(req, res);
        }

        if (type.endsWith("qingjiaDel")) {
            qingjiaDel(req, res);
        }


        if (type.endsWith("qingjiaManaFudaoyuan")) {
            qingjiaManaFudaoyuan(req, res);
        }

        if (type.endsWith("qingjiaManaAdmin")) {
            qingjiaManaAdmin(req, res);
        }

        if (type.endsWith("qingjiaShenhe")) {
            qingjiaShenhe(req, res);
        }

    }


    public void qingjiaAdd(HttpServletRequest req, HttpServletResponse res) {
        HttpSession session = req.getSession();
        Txuesheng xuesheng = (Txuesheng) session.getAttribute("xuesheng");

        int id = 0;
        String shiyou = req.getParameter("shiyou");
        String kaishishi = req.getParameter("kaishishi");
        String jieshushi = req.getParameter("jieshushi");


        int tianshu = getDaySub(kaishishi, jieshushi);
        int xuesheng_id = xuesheng.getId();
        String shenhezheleixing = "";
        if (tianshu <= 3) {
            shenhezheleixing = "����Ա";
        }
        if (tianshu > 3) {
            shenhezheleixing = "����Ա";
        }
        String shenhezt = "�����";


        String sql = "insert into t_qingjia(shiyou,kaishishi,jieshushi,tianshu,xuesheng_id,shenhezheleixing,shenhezt) values(?,?,?,?,?,?,?)";
        Object[] params = {shiyou, kaishishi, jieshushi, tianshu, xuesheng_id, shenhezheleixing, shenhezt};
        DB mydb = new DB();
        mydb.doPstm(sql, params);
        mydb.closed();

        req.setAttribute("msg", "��Ϣ������");
        String targetURL = "/common/msg.jsp";
        dispatch(targetURL, req, res);
    }


    public void qingjiaMine(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Txuesheng xuesheng = (Txuesheng) session.getAttribute("xuesheng");

        List qingjiaList = new ArrayList();
        String sql = "select * from t_qingjia where xuesheng_id=" + xuesheng.getId();
        Object[] params = {};
        DB mydb = new DB();
        try {
            mydb.doPstm(sql, params);
            ResultSet rs = mydb.getRs();
            while (rs.next()) {
                Tqingjia qingjia = new Tqingjia();

                qingjia.setId(rs.getInt("id"));
                qingjia.setShiyou(rs.getString("shiyou"));
                qingjia.setKaishishi(rs.getString("kaishishi"));
                qingjia.setJieshushi(rs.getString("jieshushi"));

                qingjia.setTianshu(rs.getInt("tianshu"));
                qingjia.setXuesheng_id(rs.getInt("xuesheng_id"));
                qingjia.setShenhezheleixing(rs.getString("shenhezheleixing"));
                qingjia.setShenhezt(rs.getString("shenhezt"));

                qingjia.setXuesheng(utilService.get_xuesheng(rs.getInt("xuesheng_id")));


                qingjiaList.add(qingjia);
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        mydb.closed();

        req.setAttribute("qingjiaList", qingjiaList);
        req.getRequestDispatcher("admin/qingjia/qingjiaMine.jsp").forward(req, res);
    }

    public void qingjiaDel(HttpServletRequest req, HttpServletResponse res) {
        String sql = "delete from t_qingjia where id=" + Integer.parseInt(req.getParameter("id"));
        Object[] params = {};
        DB mydb = new DB();
        mydb.doPstm(sql, params);
        mydb.closed();

        req.setAttribute("msg", "��Ϣɾ���ɹ�");
        String targetURL = "/common/msg.jsp";
        dispatch(targetURL, req, res);
    }

    public void qingjiaManaFudaoyuan(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Txuesheng xuesheng = (Txuesheng) session.getAttribute("xuesheng");

        List qingjiaList = new ArrayList();
        String sql = "select * from t_qingjia where shenhezheleixing=?";
        Object[] params = {"����Ա"};
        DB mydb = new DB();
        try {
            mydb.doPstm(sql, params);
            ResultSet rs = mydb.getRs();
            while (rs.next()) {
                Tqingjia qingjia = new Tqingjia();

                qingjia.setId(rs.getInt("id"));
                qingjia.setShiyou(rs.getString("shiyou"));
                qingjia.setKaishishi(rs.getString("kaishishi"));
                qingjia.setJieshushi(rs.getString("jieshushi"));

                qingjia.setTianshu(rs.getInt("tianshu"));
                qingjia.setXuesheng_id(rs.getInt("xuesheng_id"));
                qingjia.setShenhezheleixing(rs.getString("shenhezheleixing"));
                qingjia.setShenhezt(rs.getString("shenhezt"));

                qingjia.setXuesheng(utilService.get_xuesheng(rs.getInt("xuesheng_id")));


                qingjiaList.add(qingjia);
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        mydb.closed();

        req.setAttribute("qingjiaList", qingjiaList);
        req.getRequestDispatcher("admin/qingjia/qingjiaManaFudaoyuan.jsp").forward(req, res);
    }


    public void qingjiaManaAdmin(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Txuesheng xuesheng = (Txuesheng) session.getAttribute("xuesheng");

        List qingjiaList = new ArrayList();
        String sql = "select * from t_qingjia where shenhezheleixing=?";
        Object[] params = {"����Ա"};
        DB mydb = new DB();
        try {
            mydb.doPstm(sql, params);
            ResultSet rs = mydb.getRs();
            while (rs.next()) {
                Tqingjia qingjia = new Tqingjia();

                qingjia.setId(rs.getInt("id"));
                qingjia.setShiyou(rs.getString("shiyou"));
                qingjia.setKaishishi(rs.getString("kaishishi"));
                qingjia.setJieshushi(rs.getString("jieshushi"));

                qingjia.setTianshu(rs.getInt("tianshu"));
                qingjia.setXuesheng_id(rs.getInt("xuesheng_id"));
                qingjia.setShenhezheleixing(rs.getString("shenhezheleixing"));
                qingjia.setShenhezt(rs.getString("shenhezt"));

                qingjia.setXuesheng(utilService.get_xuesheng(rs.getInt("xuesheng_id")));


                qingjiaList.add(qingjia);
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        mydb.closed();

        req.setAttribute("qingjiaList", qingjiaList);
        req.getRequestDispatcher("admin/qingjia/qingjiaManaAdmin.jsp").forward(req, res);
    }


    public void qingjiaShenhe(HttpServletRequest req, HttpServletResponse res) {
        int id = Integer.parseInt(req.getParameter("id"));
        String shenhezt = req.getParameter("shenhezt");

        String sql = "update t_qingjia set shenhezt=? where id=?";
        Object[] params = {shenhezt, id};
        DB mydb = new DB();
        mydb.doPstm(sql, params);
        mydb.closed();

        req.setAttribute("msg", "��Ϣ��˳ɹ�");
        String targetURL = "/common/msg.jsp";
        dispatch(targetURL, req, res);
    }

    public int getDaySub(String beginDateStr, String endDateStr) {
        long day = 0;
        java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd");
        java.util.Date beginDate;
        java.util.Date endDate;
        try {
            beginDate = format.parse(beginDateStr);
            endDate = format.parse(endDateStr);
            day = (endDate.getTime() - beginDate.getTime()) / (24 * 60 * 60 * 1000);
            //System.out.println("���������="+day);   
        } catch (ParseException e) {
            // TODO �Զ����� catch ��
            e.printStackTrace();
        }
        return (int) day + 1;
    }


    public void dispatch(String targetURI, HttpServletRequest request, HttpServletResponse response) {
        RequestDispatcher dispatch = getServletContext().getRequestDispatcher(targetURI);
        try {
            dispatch.forward(request, response);
            return;
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void destroy() {

    }
}
