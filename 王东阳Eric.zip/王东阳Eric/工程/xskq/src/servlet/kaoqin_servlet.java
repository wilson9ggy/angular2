package servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.utilService;
import util.DB;

import model.Tkaoqin;
import model.Txuesheng;

public class kaoqin_servlet extends HttpServlet {
    public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String type = req.getParameter("type");

        if (type.endsWith("kaoqinAdd")) {
            kaoqinAdd(req, res);
        }
        if (type.endsWith("kaoqinMana")) {
            kaoqinMana(req, res);
        }
        if (type.endsWith("kaoqinDel")) {
            kaoqinDel(req, res);
        }

        if (type.endsWith("kaoqin_tongji")) {
            try {
                kaoqin_tongji(req, res);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }


        if (type.endsWith("kaoqinMine")) {
            kaoqinMine(req, res);
        }
    }

    public void kaoqinAdd(HttpServletRequest req, HttpServletResponse res) {
        //int id=0;
        String shijian = req.getParameter("shijian");
        String kecheng = req.getParameter("kecheng");
        String jieci = req.getParameter("jieci");

        String leixing = req.getParameter("leixing");
        int xuesheng_id = Integer.parseInt(req.getParameter("xuesheng_id"));

        String sql = "insert into t_kaoqin(shijian,kecheng,jieci,leixing,xuesheng_id) values(?,?,?,?,?)";
        Object[] params = {shijian, kecheng, jieci, leixing, xuesheng_id};
        DB mydb = new DB();
        mydb.doPstm(sql, params);
        mydb.closed();

        req.setAttribute("msg", "��Ϣ��ӳɹ�");
        String targetURL = "/common/msg.jsp";
        dispatch(targetURL, req, res);
    }

    public void kaoqinMana(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        List kaoqinList = new ArrayList();
        String sql = "select * from t_kaoqin";
        Object[] params = {};
        DB mydb = new DB();
        try {
            mydb.doPstm(sql, params);
            ResultSet rs = mydb.getRs();
            while (rs.next()) {
                Tkaoqin kaoqin = new Tkaoqin();

                kaoqin.setId(rs.getInt("id"));
                kaoqin.setShijian(rs.getString("shijian"));
                kaoqin.setKecheng(rs.getString("kecheng"));
                kaoqin.setJieci(rs.getString("jieci"));

                kaoqin.setLeixing(rs.getString("leixing"));
                kaoqin.setXuesheng_id(rs.getInt("xuesheng_id"));

                kaoqin.setXuesheng(utilService.get_xuesheng(rs.getInt("xuesheng_id")));
                kaoqinList.add(kaoqin);
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        mydb.closed();

        req.setAttribute("kaoqinList", kaoqinList);
        req.getRequestDispatcher("admin/kaoqin/kaoqinMana.jsp").forward(req, res);
    }


    public void kaoqinDel(HttpServletRequest req, HttpServletResponse res) {
        String sql = "delete from t_kaoqin where id=" + Integer.parseInt(req.getParameter("id"));
        Object[] params = {};
        DB mydb = new DB();
        mydb.doPstm(sql, params);
        mydb.closed();

        req.setAttribute("msg", "��Ϣɾ���ɹ�");
        String targetURL = "/common/msg.jsp";
        dispatch(targetURL, req, res);
    }


    public void kaoqin_tongji(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException, SQLException {
        String shijian1 = req.getParameter("shijian1");
        String shijian2 = req.getParameter("shijian2");

        String leixing = req.getParameter("leixing");


        String ss = req.getParameter("xuesheng_id");
        System.out.println(ss + "^^");
        DB mydb = new DB();
        ResultSet rs = null;

        if (ss == "") {
            String sql = "select * from t_kaoqin where shijian>=? and shijian<=? and leixing=?";
            Object[] params = {shijian1, shijian2, leixing};

            mydb.doPstm(sql, params);
            rs = mydb.getRs();
        } else {
            int xuesheng_id = Integer.parseInt(ss);
            String sql = "select * from t_kaoqin where shijian>=? and shijian<=? and leixing=? and xuesheng_id=?";
            Object[] params = {shijian1, shijian2, leixing, xuesheng_id};
            mydb.doPstm(sql, params);
            rs = mydb.getRs();
        }

        List kaoqinList = new ArrayList();


        try {
            while (rs.next()) {
                Tkaoqin kaoqin = new Tkaoqin();

                kaoqin.setId(rs.getInt("id"));
                kaoqin.setShijian(rs.getString("shijian"));
                kaoqin.setKecheng(rs.getString("kecheng"));

                kaoqin.setJieci(rs.getString("jieci"));
                kaoqin.setLeixing(rs.getString("leixing"));
                kaoqin.setXuesheng_id(rs.getInt("xuesheng_id"));

                kaoqin.setXuesheng(utilService.get_xuesheng(rs.getInt("xuesheng_id")));
                kaoqinList.add(kaoqin);
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        mydb.closed();

        req.getSession().setAttribute("kaoqinList", kaoqinList);
        req.getRequestDispatcher("admin/kaoqin/kaoqinMana.jsp").forward(req, res);
    }


    public void kaoqinMine(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Txuesheng xuesheng = (Txuesheng) session.getAttribute("xuesheng");

        List kaoqinList = new ArrayList();
        String sql = "select * from t_kaoqin where xuesheng_id=" + xuesheng.getId();
        Object[] params = {};
        DB mydb = new DB();
        try {
            mydb.doPstm(sql, params);
            ResultSet rs = mydb.getRs();
            while (rs.next()) {
                Tkaoqin kaoqin = new Tkaoqin();

                kaoqin.setId(rs.getInt("id"));
                kaoqin.setShijian(rs.getString("shijian"));
                kaoqin.setKecheng(rs.getString("kecheng"));
                kaoqin.setJieci(rs.getString("jieci"));

                kaoqin.setLeixing(rs.getString("leixing"));
                kaoqin.setXuesheng_id(rs.getInt("xuesheng_id"));

                kaoqin.setXuesheng(utilService.get_xuesheng(rs.getInt("xuesheng_id")));
                kaoqinList.add(kaoqin);
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        mydb.closed();

        req.setAttribute("kaoqinList", kaoqinList);
        req.getRequestDispatcher("admin/kaoqin/kaoqinMine.jsp").forward(req, res);
    }

    public void dispatch(String targetURI, HttpServletRequest request, HttpServletResponse response) {
        RequestDispatcher dispatch = getServletContext().getRequestDispatcher(targetURI);
        try {
            dispatch.forward(request, response);
            return;
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void destroy() {

    }
}
