package servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.DB;


public class laoshi_servlet extends HttpServlet {
    public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String type = req.getParameter("type");

        if (type.endsWith("laoshiEditMe")) {
            laoshiEditMe(req, res);
        }
    }


    public void laoshiEditMe(HttpServletRequest req, HttpServletResponse res) {
        String bianhao = req.getParameter("bianhao");
        String xingming = req.getParameter("xingming");
        String xingbie = req.getParameter("xingbie");
        String nianling = req.getParameter("nianling");

        String loginpw = req.getParameter("loginpw");
        int id = Integer.parseInt(req.getParameter("id"));


        String sql = "update t_laoshi set bianhao=?,xingming=?,xingbie=?,nianling=?,loginpw=? where id=?";
        Object[] params = {bianhao, xingming, xingbie, nianling, loginpw, id};
        DB mydb = new DB();
        mydb.doPstm(sql, params);
        mydb.closed();

        req.setAttribute("msg", "�޸ĳɹ������µ�½����Ч");
        String targetURL = "/common/msg.jsp";
        dispatch(targetURL, req, res);
    }


    public void dispatch(String targetURI, HttpServletRequest request, HttpServletResponse response) {
        RequestDispatcher dispatch = getServletContext().getRequestDispatcher(targetURI);
        try {
            dispatch.forward(request, response);
            return;
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void destroy() {

    }
}
