package model;

public class Tkaoqin {
    private int id;
    private String shijian;
    private String kecheng;
    private String jieci;


    private String leixing;
    private int xuesheng_id;

    private Txuesheng xuesheng;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getJieci() {
        return jieci;
    }

    public void setJieci(String jieci) {
        this.jieci = jieci;
    }

    public String getKecheng() {
        return kecheng;
    }

    public void setKecheng(String kecheng) {
        this.kecheng = kecheng;
    }

    public String getLeixing() {
        return leixing;
    }

    public void setLeixing(String leixing) {
        this.leixing = leixing;
    }

    public String getShijian() {
        return shijian;
    }

    public void setShijian(String shijian) {
        this.shijian = shijian;
    }


    public Txuesheng getXuesheng() {
        return xuesheng;
    }

    public void setXuesheng(Txuesheng xuesheng) {
        this.xuesheng = xuesheng;
    }

    public int getXuesheng_id() {
        return xuesheng_id;
    }

    public void setXuesheng_id(int xuesheng_id) {
        this.xuesheng_id = xuesheng_id;
    }


}
