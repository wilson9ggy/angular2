package model;

public class Tqingjia {
    private int id;
    private String shiyou;
    private String kaishishi;
    private String jieshushi;


    private int tianshu;
    private int xuesheng_id;
    private String shenhezheleixing;
    private String shenhezt;

    private Txuesheng xuesheng;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getShiyou() {
        return shiyou;
    }

    public void setShiyou(String shiyou) {
        this.shiyou = shiyou;
    }

    public String getKaishishi() {
        return kaishishi;
    }

    public void setKaishishi(String kaishishi) {
        this.kaishishi = kaishishi;
    }

    public String getJieshushi() {
        return jieshushi;
    }

    public void setJieshushi(String jieshushi) {
        this.jieshushi = jieshushi;
    }

    public int getTianshu() {
        return tianshu;
    }

    public Txuesheng getXuesheng() {
        return xuesheng;
    }

    public void setXuesheng(Txuesheng xuesheng) {
        this.xuesheng = xuesheng;
    }

    public void setTianshu(int tianshu) {
        this.tianshu = tianshu;
    }

    public int getXuesheng_id() {
        return xuesheng_id;
    }

    public void setXuesheng_id(int xuesheng_id) {
        this.xuesheng_id = xuesheng_id;
    }

    public String getShenhezheleixing() {
        return shenhezheleixing;
    }

    public void setShenhezheleixing(String shenhezheleixing) {
        this.shenhezheleixing = shenhezheleixing;
    }

    public String getShenhezt() {
        return shenhezt;
    }

    public void setShenhezt(String shenhezt) {
        this.shenhezt = shenhezt;
    }

}
