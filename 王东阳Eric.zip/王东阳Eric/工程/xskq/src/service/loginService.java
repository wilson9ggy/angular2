package service;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import model.TAdmin;
import model.Tlaoshi;
import model.Txuesheng;

import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;

import util.DB;


public class loginService {


    public String login(String userName, String userPw, int userType) {
        System.out.println("userType" + userType);
        try {
            Thread.sleep(700);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        String result = "no";

        if (userType == 0)//ϵͳ����Ա��½
        {
            String sql = "select * from t_admin where userName=? and userPw=?";
            Object[] params = {userName, userPw};
            DB mydb = new DB();
            mydb.doPstm(sql, params);
            try {
                ResultSet rs = mydb.getRs();
                boolean mark = (rs == null || !rs.next() ? false : true);
                if (mark == false) {
                    result = "no";
                } else {
                    result = "yes";
                    TAdmin admin = new TAdmin();
                    admin.setUserId(rs.getInt("userId"));
                    admin.setUserName(rs.getString("userName"));
                    admin.setUserPw(rs.getString("userPw"));
                    WebContext ctx = WebContextFactory.get();
                    HttpSession session = ctx.getSession();
                    session.setAttribute("userType", 0);
                    session.setAttribute("admin", admin);
                }
                rs.close();
            } catch (SQLException e) {
                System.out.println("��¼ʧ�ܣ�");
                e.printStackTrace();
            } finally {
                mydb.closed();
            }

        }


        if (userType == 1) {
            String sql = "select * from t_laoshi where del='no' and bianhao=? and loginpw=?";
            Object[] params = {userName.trim(), userPw.trim()};
            DB mydb = new DB();
            mydb.doPstm(sql, params);
            try {
                ResultSet rs = mydb.getRs();
                boolean mark = (rs == null || !rs.next() ? false : true);
                if (mark == false) {
                    result = "no";
                } else {
                    result = "yes";

                    Tlaoshi laoshi = new Tlaoshi();

                    laoshi.setId(rs.getInt("id"));
                    laoshi.setBianhao(rs.getString("bianhao"));
                    laoshi.setXingming(rs.getString("xingming"));
                    laoshi.setXingbie(rs.getString("xingbie"));

                    laoshi.setNianling(rs.getString("nianling"));
                    laoshi.setLoginpw(rs.getString("loginpw"));
                    laoshi.setDel(rs.getString("del"));

                    WebContext ctx = WebContextFactory.get();
                    HttpSession session = ctx.getSession();
                    session.setAttribute("userType", 1);
                    session.setAttribute("laoshi", laoshi);
                }
                rs.close();
            } catch (SQLException e) {
                System.out.println("��¼ʧ�ܣ�");
                e.printStackTrace();
            } finally {
                mydb.closed();
            }
        }
        if (userType == 2) {
            String sql = "select * from t_xuesheng where del='no' and xuehao=? and loginpw=?";
            Object[] params = {userName.trim(), userPw.trim()};
            DB mydb = new DB();
            mydb.doPstm(sql, params);
            try {
                ResultSet rs = mydb.getRs();
                boolean mark = (rs == null || !rs.next() ? false : true);
                if (mark == false) {
                    result = "no";
                } else {
                    result = "yes";

                    Txuesheng xuesheng = new Txuesheng();

                    xuesheng.setId(rs.getInt("id"));
                    xuesheng.setXuehao(rs.getString("xuehao"));
                    xuesheng.setXingming(rs.getString("xingming"));
                    xuesheng.setXingbie(rs.getString("xingbie"));

                    xuesheng.setNianling(rs.getString("nianling"));
                    xuesheng.setLoginpw(rs.getString("loginpw"));
                    xuesheng.setDel(rs.getString("del"));

                    WebContext ctx = WebContextFactory.get();
                    HttpSession session = ctx.getSession();
                    session.setAttribute("userType", 2);
                    session.setAttribute("xuesheng", xuesheng);
                }
                rs.close();
            } catch (SQLException e) {
                System.out.println("��¼ʧ�ܣ�");
                e.printStackTrace();
            } finally {
                mydb.closed();
            }
        }
        return result;
    }

    public String adminPwEdit(String userPwNew) {
        System.out.println("DDDD");
        try {
            Thread.sleep(700);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        WebContext ctx = WebContextFactory.get();
        HttpSession session = ctx.getSession();
        TAdmin admin = (TAdmin) session.getAttribute("admin");

        String sql = "update t_admin set userPw=? where userId=?";
        Object[] params = {userPwNew, admin.getUserId()};
        DB mydb = new DB();
        mydb.doPstm(sql, params);

        return "yes";
    }

}
