package service;


import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Txuesheng;
import util.DB;

public class utilService {
    public static Txuesheng get_xuesheng(int id) {
        Txuesheng xuesheng = new Txuesheng();
        String sql = "select * from t_xuesheng where id=?";
        Object[] params = {id};
        DB mydb = new DB();
        try {
            mydb.doPstm(sql, params);
            ResultSet rs = mydb.getRs();
            while (rs.next()) {
                xuesheng.setId(rs.getInt("id"));
                xuesheng.setXuehao(rs.getString("xuehao"));
                xuesheng.setXingming(rs.getString("xingming"));
                xuesheng.setXingbie(rs.getString("xingbie"));


                xuesheng.setNianling(rs.getString("nianling"));
                xuesheng.setLoginpw(rs.getString("loginpw"));
                xuesheng.setDel(rs.getString("del"));
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        mydb.closed();
        return xuesheng;
    }
}
