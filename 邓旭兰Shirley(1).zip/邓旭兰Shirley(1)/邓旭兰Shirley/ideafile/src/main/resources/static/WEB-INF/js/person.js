
/** table鼠标悬停换色* */
$(function() {
    // 如果鼠标移到行上时，执行函数
    $(".table tr").mouseover(function() {
        $(this).css({background : "#CDDAEB"});
        $(this).children('td').each(function(index, ele){
            $(ele).css({color: "#1D1E21"});
        });
    }).mouseout(function() {
        $(this).css({background : "#FFF"});
        $(this).children('td').each(function(index, ele){
            $(ele).css({color: "#909090"});
        });
    });
});