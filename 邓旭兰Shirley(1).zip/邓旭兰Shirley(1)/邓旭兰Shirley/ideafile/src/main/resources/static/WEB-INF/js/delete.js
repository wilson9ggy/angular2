//全选
function ckAll(){
    var flag=document.getElementById("allChecks").checked;
    var cks=document.getElementsByName("check");
    for(var i=0;i<cks.length;i++){
        cks[i].checked=flag;
    }
}
//批量删除
function delAllPerson(){
    if(!confirm("确定要删除这些人员吗？")){
        return ;
    }
    var cks=document.getElementsByName("check");
    var str="";
    //拼接所有的人员id
    for(var i=0;i<cks.length;i++){
        if(cks[i].checked){
            str+="id="+cks[i].value+"&";
        }
    }
    //去掉字符串末尾的‘&’
    str=str.substring(0, str.length-1);
    location.href="${pageContext.request.contextPath}/servlet/delAllBooksServlet?"+str;
}

//删除？？？
function del() {
    if (confirm("确认删除吗")) {
        document.getElementById()
        window.location.href('springboot/deletePerson/')
    }
    else {
        return;
    }
}