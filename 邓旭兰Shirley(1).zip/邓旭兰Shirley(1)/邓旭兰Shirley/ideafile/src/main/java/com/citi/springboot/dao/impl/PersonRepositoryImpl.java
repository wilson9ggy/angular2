package com.citi.springboot.dao.impl;

import com.citi.springboot.dao.PersonRepository;
import com.citi.springboot.entity.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class PersonRepositoryImpl implements PersonRepository{
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Override
    public List<Person> findAll() {
        List<Person> list = jdbcTemplate.query("select * from person", new Object[]{}, new BeanPropertyRowMapper(Person.class));
        if(list!=null && list.size()>0){
            return list;
        }else{
            return null;
        }

    }

    @Override
    public Person findById(Integer id) {
        try {
            Person person = jdbcTemplate.queryForObject("select * from person where id = ?", new Object[]{id}, new BeanPropertyRowMapper<Person>(Person.class));
            return person;
        } catch (DataAccessException e) {
            return null;
        }
    }

    @Override
    public List<Person> findByAge(Integer age) {
        List<Person> list = jdbcTemplate.query("SELECT ID,NAME,AGE FROM PERSON WHERE AGE=?", new Object[]{age}, new BeanPropertyRowMapper(Person.class));
        if(list!=null && list.size()>0){
            return list;
        }else{
            return null;
        }
    }

    @Override
    public List<Person> findByAny(String str) {
        List<Person> list = jdbcTemplate.query("SELECT ID,NAME,AGE FROM PERSON ID LIKE CONCAT('%',?,'%') OR NAME LIKE CONCAT('%',?,'%') OR AGE LIKE CONCAT('%',?,'%')", new Object[]{str}, new BeanPropertyRowMapper(Person.class));
        if(list!=null && list.size()>0){
            return list;
        }else{
            return null;
        }
    }

    @Override
    public Integer deletePersonById(Integer id) {
        return jdbcTemplate.update("DELETE from TABLE person where id=?",id);
    }

    @Override
    public Integer savePerson(Person person) {
        return jdbcTemplate.update("insert into person(name, age) values(?, ?)",
                person.getName(),person.getAge());
    }

    @Override
    public Integer updatePerson(Person person) {
        return jdbcTemplate.update("UPDATE  person SET NAME=? ,AGE=? WHERE id=?",
                person.getName(),person.getAge(),person.getId());
    }
}
