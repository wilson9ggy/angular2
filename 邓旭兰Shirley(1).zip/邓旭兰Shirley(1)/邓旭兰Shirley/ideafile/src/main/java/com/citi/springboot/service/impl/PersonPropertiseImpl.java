package com.citi.springboot.service.impl;

import com.citi.springboot.dao.PersonRepository;
import com.citi.springboot.entity.Person;
import com.citi.springboot.service.PersonPropertise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PersonPropertiseImpl implements PersonPropertise {
    @Autowired
    PersonRepository personRepository;
    @Override
    public List<Person> findAll() {
        return personRepository.findAll();
    }

    @Override
    public Person findById(Integer id) {
        return personRepository.findById(id);
    }

    @Override
    public List<Person> findByAge(Integer age) {
        return personRepository.findByAge(age);
    }

    @Override
    public List<Person> findByAny(String str) {
        return personRepository.findByAny(str);
    }

    @Override
    public Integer deletePersonById(Integer id) {
        return personRepository.deletePersonById(id);
    }

    @Override
    public Integer savePerson(Person person) {
        return personRepository.savePerson(person);
    }

    @Override
    public Integer updatePerson(Person person) {
        return personRepository.updatePerson(person);
    }
}
