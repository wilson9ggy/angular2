package com.citi.springboot.dao;
import com.citi.springboot.entity.Person;

import java.util.List;

/**
 * Created by Shirley
 * Time: 2018/09/04 15:07
 */
public interface PersonRepository {

    /**
     *  查询所有人员信息
     * @param
     * @return 所有人员信息表
     */
    public List<Person> findAll();

    /**
     *  通过id查找人员信息
     * @param id
     * @return 查找的id号对应的人员信息
     */
    public Person findById(Integer id);

    /**
     *  通过年龄来查询
     *  方法名固定
     * @param age
     * @return
     */
    public List<Person> findByAge(Integer age);

    /**
     *  模糊查找
     * @param str
     * @return 含关键字的人员信息
     */
    public List<Person> findByAny(String str);

    /**
     *  删除人员信息
     * @param id
     * @return 1:true(delete seccess)
     *          2:false(delete filed)
     */
    public Integer deletePersonById(Integer id);
    /**
     * 添加人员信息
     * @param person
     *@return 1:true(save seccess)
     *         2:false(save filed)
     */
    public Integer savePerson(Person person);
    /**
     *  更新人员信息
     * @param person
     *@return 1:true(update seccess)
     *         2:false(update filed)
     */
    public Integer updatePerson(Person person);


}
