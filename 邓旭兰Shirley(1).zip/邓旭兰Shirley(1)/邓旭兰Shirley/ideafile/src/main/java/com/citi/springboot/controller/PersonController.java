
package com.citi.springboot.controller;

import com.citi.springboot.dao.impl.PersonRepositoryImpl;
import com.citi.springboot.service.impl.PersonPropertiseImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.citi.springboot.entity.Person;
import org.springframework.ui.Model;
import java.util.List;

/**
 *
 * Created by Peng
 * Time: 2016/12/16 18:04
 */
@Controller
public class PersonController {

    @Autowired
    PersonRepositoryImpl personRepository;

    /**
     * 查询所有人员列表
     *
     * @return
     */
    @RequestMapping("/listPerson")
    public String listPerson(Model m) throws Exception {
//        List<Person> cs=personRepository.findAll();
//        m.addAttribute("ps", cs);
        return "person";
    }
    /**
     * 通过id查询一个人员
     *
     * @param id
     * @return
     */
    @GetMapping(value = "/findPerson/?id={id}")
    public Person personFindOne(@PathVariable("id") Integer id) {
        return personRepository.findById(id);
    }

    /**
     * 通过年龄来查询
     * @param age
     * @return
     */
    @GetMapping(value = "/findPerson/?age={age}")
    public List<Person> personListByAge(@PathVariable("age") Integer age) {
        return personRepository.findByAge(age);
    }

    /**
     * 添加一个人员
     *
     * @param name
     * @param age
     * @return
     */
    @PostMapping(value = "/insertPerson/?name={name}&age={age}")
    public String personAdd(@PathVariable("name") String name,
                            @PathVariable("age") Integer age) {
        Person person = new Person();
        person.setName(name);
        person.setAge(age);
        int t= personRepository.savePerson(person);
        if(t==1){
            return person.toString();
        }else {
            return "fail";
        }
    }


    /**
     * 删除一个人员
     *
     * @param id
     */
    @DeleteMapping(value = "/deletePerson/?id={id}")
    public String personDelete(@PathVariable("id") Integer id) {
        int t= personRepository.deletePersonById(id);
        if(t==1){
            return id.toString();
        }else {
            return "fail";
        }
    }

    /**
     * 更新一个人员
     *
     * @param id
     * @param name
     * @param age
     * @return
     */
    @PutMapping(value = "/updatePerson/?id={id}&name={name}&age={age}")
    public String personUpdate(@PathVariable("id") Integer id,
                               @PathVariable("name") String name,
                               @PathVariable("age") Integer age) {
        Person person = new Person();
        person.setId(id);
        person.setName(name);
        person.setAge(age);
        int t=personRepository.updatePerson(person);
        if(t==1){
            return person.toString();
        }else {
            return "fail";
        }
    }

}