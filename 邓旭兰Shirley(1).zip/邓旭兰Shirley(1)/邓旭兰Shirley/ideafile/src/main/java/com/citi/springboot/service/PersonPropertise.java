package com.citi.springboot.service;

import com.citi.springboot.entity.Person;

import java.util.List;

public interface PersonPropertise {
    /**
     *  find all person
     * @param
     * @return a list of all person
     */
    public List<Person> findAll();

    /**
     *  find the person by Id
     * @param id
     * @return a list of person whose id was searched
     */
    public Person findById(Integer id);

    /**
     *  通过年龄来查询
     *  方法名固定
     * @param age
     * @return
     */
    public List<Person> findByAge(Integer age);

    /**
     *  find the list of person by Any
     * @param str
     * @return a list of person who has the keyword
     */
    public List<Person> findByAny(String str);

    /**
     *  delete the person
     * @param id
     * @return 1:true(delete seccess)
     *          2:false(delete filed)
     */
    public Integer deletePersonById(Integer id);
    /**
     *  save the person
     * @param person
     *@return 1:true(save seccess)
     *         2:false(save filed)
     */
    public Integer savePerson(Person person);
    /**
     *  update the person
     * @param person
     *@return 1:true(update seccess)
     *         2:false(update filed)
     */
    public Integer updatePerson(Person person);

}
